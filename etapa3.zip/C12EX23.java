package etapa3.C12;

import java.util.Scanner;

public class C12EX23 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int[] n = new int[10];
        int[] n3 = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.println("Digite o numero " + (i + 1));
            n[i] = teclado.nextInt();
        }

        for (int i = 0; i < 10; i++) {
            if (n[i] % 3 == 0 ) {
                n3[i] = n[i];
            }
        }
        for (int i = 0; i < 10; i++) {
            if (n3[i] != 0)
                System.out.println(n3[i]);
        }
    }
}

