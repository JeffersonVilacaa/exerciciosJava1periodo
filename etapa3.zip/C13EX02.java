package etapa3.C13;

import java.util.Scanner;

public class C13EX02 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        C13EX02C obj = new C13EX02C();
        double x = 0;

        while (true){
            System.out.print("Digite um valor de x: ");
            x = teclado.nextDouble();

            if(x == -1)
                break;

            System.out.println(obj.func(x));
        }
    }
}

