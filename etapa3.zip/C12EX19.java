package etapa3.C12;

import java.util.Scanner;

public class C12EX19 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] nums = new int[10];
        int[] numsInv = new int[10];
        int count = nums.length - 1;

        for (int i = 0; i < nums.length; i++) {
            System.out.println("Enter the number " + (i + 1) + ": ");
            nums[i] = teclado.nextInt();
            numsInv[count] += nums[i];
            count--;
        }

        for (int i = 0; i < nums.length; i++) {
            System.out.print(numsInv[i] + " ");
        }
    }
}
