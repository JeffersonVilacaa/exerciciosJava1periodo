package etapa3.C12;

import java.util.Scanner;

public class C12EX22 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String[] placa = new String[5];
        String[] nome = new String[5];

        for (int i = 0; i < placa.length; i++) {
            System.out.println("Escreva o nome do morador");
            nome[i] = teclado.next().toLowerCase();
            System.out.println("Escreva a placa");
            placa[i] = teclado.next().toLowerCase();
        }

        System.out.println("Deseja pesquisar pela placa(P) ou pelo nome(N)?");
        char pesquisa = teclado.next().charAt(0);

        if (pesquisa == 'P') {
            System.out.println("Digite a placa que deseja pesquisar");
            String pPlaca = teclado.next();

            for (int i = 0; i < placa.length; i++) {
                if (placa[i].equals(pPlaca)) {
                    System.out.println("Sua vaga e " + i);
                }
            }
        }
        else {
            System.out.println("Digite a placa que deseja pesquisar");
            String pNome = teclado.next();

            for (int i = 0; i < placa.length; i++) {
                if (placa[i].equals(pNome)) {
                    System.out.println("Sua vaga e " + i);
                }
            }
        }
    }
}

