package etapa3.C15;

public class C15EX01teste {

    public static void main(String[] args) {
        // Criando três objetos diferentes de Produto
        C15EX01 produto1 = new C15EX01(1, "Camiseta", 29.90, 50, "Vestuário");
        C15EX01 produto2 = new C15EX01(2, "Notebook", 2999.99, 10, "Eletrônicos");
        C15EX01 produto3 = new C15EX01(3, "Livro", 45.00, 100, "Cultura");

        // Imprimindo os dados de cada produto
        System.out.println("Produto 1:");
        produto1.imprimirProduto();
        System.out.println();

        System.out.println("Produto 2:");
        produto2.imprimirProduto();
        System.out.println();

        System.out.println("Produto 3:");
        produto3.imprimirProduto();
        System.out.println();

        // Exemplo de utilização de métodos
        produto1.adicionarEstoque(20); // Adicionando 20 unidades ao estoque do produto1
        System.out.println("Valor total do estoque do Produto 1: R$" + produto1.calcularValorTotal());
    }
}
