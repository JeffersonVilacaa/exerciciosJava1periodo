package etapa3.C12;

import java.util.Scanner;

public class C12EX06 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String nome[] = new String[5];
        int nota[] = new int [5];

        for (int aux = 0; aux < nome.length; aux ++) {
            System.out.print("Digite o nome do aluno: ");
            nome[aux] = teclado.nextLine();
            System.out.println("Digite a nota do aluno: ");
            nota[aux] = teclado.nextInt();
            teclado.nextLine();
        }

        for (int aux = 0; aux >= nome.length; aux++){
            if (nota[aux] > 80 ){
                System.out.println(nome[aux] + nota[aux] + " - Conceito A ");
            } else if (nota[aux] < 80  & nota [aux] > 60){
                System.out.println(nome[aux] + nota[aux] + " - Conceito B ");
            } else if (nota[aux] < 61  & nota [aux] > 30){
                System.out.println(nome[aux] + nota[aux] + " - Conceito C ");
            } else {
                System.out.println(nome[aux] + nota[aux] + " - Conceito D ");
            }
        }
    }


}
