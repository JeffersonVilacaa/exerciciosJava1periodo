package etapa3.C13;

import java.util.Scanner;

public class C13EX01 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Digite x1: ");
        int x1 = teclado.nextInt();
        System.out.print("Digite y1: ");
        int y1 = teclado.nextInt();
        System.out.print("Digite x2: ");
        int x2 = teclado.nextInt();
        System.out.print("Digite y2: ");
        int y2 = teclado.nextInt();

        double resp = coord(x1, x2, y1, y2);
        System.out.print(resp);
    }

    static double coord(double x1,double x2, double y1, double y2) {
        double x = x2 - x1;
        double y = y2 - y1;
        return Math.sqrt((x * x) + (y * y));
    }
}

