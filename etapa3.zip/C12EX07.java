package etapa3.C12;

import java.util.Scanner;

public class C12EX07 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String meses[] = new String[12];


        for (int aux = 0; aux < meses.length; aux ++) {
            System.out.print("Digite o mês: ");
            meses[aux] = teclado.nextLine();
        }

        System.out.println("Os meses do ano ao contrário são: ");
        for (int aux = 11; aux >= 0; aux --) {
            System.out.println(meses[aux]);
        }
        teclado.close();
    }
}
