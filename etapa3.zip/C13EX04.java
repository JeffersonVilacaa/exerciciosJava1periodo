package etapa3.C13;

import java.util.Scanner;

public class C13EX04 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);


    }
}

