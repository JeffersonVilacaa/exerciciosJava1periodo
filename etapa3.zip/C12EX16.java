package etapa3.C12;

import java.util.Scanner;

public class C12EX16 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String[] nome = new String[11];
        String[] estado = new String[11];
        int[] populacao = new int[11];

        for (int i = 0; i < nome.length; i++) {
            System.out.println("Digite o nome da cidade: ");
            nome[i] = teclado.nextLine();
            System.out.println("Digite o estado da cidade: ");
            estado[i] = teclado.nextLine();
            System.out.println("Digite a população da cidade: ");
            populacao[i] = teclado.nextInt();
            teclado.nextLine();
        }

        for (int i = 0; i < nome.length - 1; i++) {
            for (int j = 0; j < nome.length - 1; j++) {
                if (populacao[j] < populacao[j + 1]) {

                    int tempPop = populacao[j];
                    populacao[j] = populacao[j+1];
                    populacao[j+1] = tempPop;

                    String tempNome = nome[j];
                    nome[j] = nome[j+1];
                    nome[j+1] = tempNome;

                    String tempEstado = estado[j];
                    estado[j] = estado[j+1];
                    estado[j+1] = tempEstado;
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            System.out.println(estado[i] + " - " + nome[i]
                    + " - " + populacao[i]);
        }
    }
}

