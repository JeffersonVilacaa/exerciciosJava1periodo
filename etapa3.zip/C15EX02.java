package etapa3.C15;

public class C15EX02 extends C15EX01 {
    // Novos atributos adicionados
    private int garantiaMeses;
    private String material;

    // Construtor com parâmetros adicionais
    public C15EX02(int codigo, String nome, double preco, int quantidadeEstoque, String categoria, int garantiaMeses, String material) {
        super(codigo, nome, preco, quantidadeEstoque, categoria);
        this.garantiaMeses = garantiaMeses;
        this.material = material;
    }

    // Novo método específico para produtos duráveis
    public void exibirDetalhesProdutoDuravel() {
        System.out.println("Detalhes do Produto Durável:");
        imprimirProduto(); // Método herdado de Produto
        System.out.println("Garantia: " + this.garantiaMeses + " meses");
        System.out.println("Material: " + this.material);
    }

    // Getter para a garantia em meses
    public int getGarantiaMeses() {
        return garantiaMeses;
    }

    // Setter para a garantia em meses
    public void setGarantiaMeses(int garantiaMeses) {
        this.garantiaMeses = garantiaMeses;
    }

    // Getter para o material do produto durável
    public String getMaterial() {
        return material;
    }

    // Setter para o material do produto durável
    public void setMaterial(String material) {
        this.material = material;
    }
}



