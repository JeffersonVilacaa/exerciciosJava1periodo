package etapa3.C12;

import java.util.Scanner;

public class C12EX04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int nums[] = new int[20];
        String pares[] = new String[10];

        for (int i = 0; i < nums.length; i++) {
            System.out.print("Digite a posição do corredor " + (i + 1) + " : ");
            nums[i] = sc.nextInt();
        }
        for (int i = 0; i < pares.length; i++) {
            pares[i] = nums[i] + "/" + nums[(i + 10)];
            System.out.println("par numero " + (i+1) + ": " + pares[i]);
        }
    }
}
