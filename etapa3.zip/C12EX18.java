package etapa3.C12;

import java.util.Scanner;

public class C12EX18 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double[] nums = new double[10];

        for (int i = 0 ; i < nums.length ; i++) {
            System.out.print("Enter the number " + (i + 1) + ": ");
            nums[i] = teclado.nextDouble();
        }

        System.out.print("Enter a multiplier for the numbers: ");
        double mult = teclado.nextDouble();

        for (int i = 0 ; i < nums.length ; i++) {
            nums[i] *= mult;
            System.out.print(nums[i] + " ");
        }
    }
}
