package etapa3.C12;

import java.util.Scanner;

public class C12EX21 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] nums = new int[10];

        for (int i = 0; i < nums.length; i++) {
            System.out.println("Enter number: " + (i + 1) + " ");
            nums[i] = teclado.nextInt();
        }
        for (int i = 0; i < nums.length; i += 2) {
            System.out.print(nums[i] + " ");
        }
        for (int i = 1; i < nums.length; i += 2) {
            System.out.print(nums[i] + " ");
        }
    }
}
