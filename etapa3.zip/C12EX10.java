package etapa3.C12;

import java.util.Arrays;
import java.util.Scanner;

public class C12EX10 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String[] aluno = new String[5];
        double[] nota = new double[5];

        for (int i = 0; i < aluno.length; i++ ) {
            System.out.println("Digite o nome do aluno: ");
            aluno[i] = teclado.nextLine();
            System.out.println("Digite a nota do aluno: ");
            nota[i] = teclado.nextDouble();
            teclado.nextLine();
        }

        double media = Arrays.stream(nota).sum() / Arrays.stream(nota).count();

        for (int i = 0; i < aluno.length; i++) {
            if (nota[i] > media)
                System.out.println(aluno[i] + "| ");
        }
    }
}

