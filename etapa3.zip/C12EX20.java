package etapa3.C12;

import java.util.Scanner;

public class C12EX20 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] nums = new int[10];
        double count = 0, sum = 0;


        for (int i = 0; i < nums.length; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            nums[i] = teclado.nextInt();
        }

        for (int i = 0; i < nums.length; i++) {
            if (nums[i] > nums[nums.length - 1]) {
                System.out.println(nums[i] + " is greater than " + nums[nums.length - 1]);
                count++;
                sum += nums[i];
            }
        }
        System.out.println("Avg: " + sum / count);
    }
}
