package etapa3.C12;

import java.util.Scanner;

public class C12EX24 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        String[] times = new String[20];
        int[] pts = new int[20];

        for (int i = 0; i < times.length; i++) {
            System.out.println("Escreva o nome do time");
            times[i] = teclado.next().toLowerCase();
            System.out.println("Escreva a quantidade de pontos");
            pts[i] = teclado.nextInt();
        }

        for (int i = 0; i < times.length - 1; i++) {
            for (int j = i + 1; j < times.length; j++) {
                if (pts[j] > pts[j + 1]) {
                    int tempPts = pts[j];
                    pts[j] = pts[j + 1];
                    pts[j + 1] = tempPts;
                    String tempTime = times[i];
                    times[j] = times[j + 1];
                    times[j + 1] = tempTime;
                }
            }
        }
        System.out.println("Digite o nome do time que deseja encontrar");
        String time = teclado.next().toLowerCase();

        for (int i = 0; i < times.length; i++) {
            if (times[i].equals(time)) {
                System.out.println(times[i] + "ficou na posição " + i);
                if (i <= 4)  {
                    System.out.print(" Copa Libertadores");
                }
                else if(i <= 12){
                    System.out.print(" Copa Sul-americana");
                }
                else{
                    System.out.println(" Rebaixado");
                }
            }
        }
    }
}
