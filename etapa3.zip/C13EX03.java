package etapa3.C13;

import java.util.Arrays;
import java.util.Scanner;

public class C13EX03 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.println("Digite um valor de 0 ate 999999999: ");
        String x = teclado.nextLine();
        System.out.println("Digite qual index você quer: ");
        int pos = teclado.nextInt();

        String value = func(x, pos);
        System.out.println(value);
    }
    static String func(String x, int pos) {
        String[] nums = x.split("");
        return nums[nums.length - pos];
    }
}

