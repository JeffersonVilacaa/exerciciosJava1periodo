package etapa3.C12;

import java.util.Scanner;

public class C12EX17 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] nums = new int[10];
        int count = 0, sum = 0;


        for (int i = 0; i < nums.length; i++) {
            System.out.print("Enter the number " + (i + 1) + ": ");
            nums[i] = teclado.nextInt();
        }

        for (int i = 0; i < nums.length ; i++) {
            if (nums[i] % 2 == 0) {
                sum += nums[i];
                count++;
                System.out.println("Number " + count + ": " + nums[i] + " ");
            }
        }
        System.out.println("Average of the numbers is: " + sum / count );
    }
}
