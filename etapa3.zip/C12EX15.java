package etapa3.C12;

import java.util.Scanner;

public class C12EX15 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        String[] month = new String[12];

        for (int i = 0; i < month.length; i++) {
            System.out.println("Digite o nome do " + (i) + ": ");
            month[i] = teclado.nextLine();
        }

        for (int i = 0; i < month.length - 1; i++) {
            for (int j = 0; j < month.length - 1; j++) {
                if (month[j].compareTo(month[j + 1]) > 0) {
                    String temp = month[j];
                    month[j] = month[j+1];
                    month[j+1] = temp;
                }
            }
        }

        System.out.println(month[0] + " " + month[1] + " " + month[2] + " " + month[3] + " " +
                month[4] + " " + month[5] + " " + month[6] + " " + month[7] + " " + month[8] +
                " " + month[9] + " " + month[10] + " " + month[11] );
    }
}
