package etapa3.C12;

import java.util.Scanner;

public class C12EX12 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String[] aluno = new String[5];
        double[] nota = new double[5];
        double maior = 0;
        String maiorNome = "";

        for (int i = 0; i < aluno.length; i++ ) {
            System.out.println("Digite o nome do aluno: ");
            aluno[i] = teclado.nextLine();
            System.out.println("Digite a nota do aluno: ");
            nota[i] = teclado.nextDouble();
            teclado.nextLine();

            if (nota[i] > maior || maior == 0) {
                maior = nota[i];
                maiorNome = aluno[i];
            }
        }

        System.out.print("As maiores nota foram dos alunos: ");
        for (int i = 0; i < aluno.length; i++ ) {
            if (nota[i] == maior) {
                System.out.print(aluno[i] + ", ");
            }
        }
    }
}
