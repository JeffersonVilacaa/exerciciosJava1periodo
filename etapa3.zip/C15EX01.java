package etapa3.C15;
//Código comentado para entender a matéria

public class C15EX01 {
    // Variaveis privadas da classe Produto
    private int codigo;
    private String nome;
    private double preco;
    private int quantEstoque;
    private String categoria;

    // Construtor com parâmetros para inicializar todos as variáveis
    public C15EX01(int codigo, String nome, double preco, int quantEstoque, String categoria) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quantEstoque = quantEstoque;
        this.categoria = categoria;
    }

    // Adiciona quantidade ao estoque
    public void adicionarEstoque(int quantidade) {
        this.quantEstoque += quantidade;
        System.out.println("Estoque atualizado para " + this.quantEstoque + " unidades.");
    }

    // Calcula o valor total do estoque
    public double calcularValorTotal() {
        return this.preco * this.quantEstoque;
    }

    //Saída de Dados
    public void imprimirProduto() {
        System.out.println("Código: " + this.codigo);
        System.out.println("Nome: " + this.nome);
        System.out.println("Preço: R$" + this.preco);
        System.out.println("Quantidade em Estoque: " + this.quantEstoque);
        System.out.println("Categoria: " + this.categoria);
    }

    public int getCodigo() {
        return codigo;
    }
}
