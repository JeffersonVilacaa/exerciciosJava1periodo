package etapa3.C13;

public class C13EX02C {
    public double func(double x) {
        if (x < 4) {
            double num = x*5 + 3;
            double den = 16 - Math.pow(x, 2);
            return num/Math.sqrt(den);
        }
        else if (x > 4) {
            double num = x*5 + 3;
            double den = Math.pow(x, 2) - 16;
            return num/Math.sqrt(den);
        }
        else {
            return 0;
        }
    }
}

