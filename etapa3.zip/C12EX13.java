package etapa3.C12;

import java.util.Scanner;

public class C12EX13 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String[] fila = new String[5];

        for (int i = 0; i < fila.length; i++) {
            System.out.println("Digite o nome: ");
            fila[i] = teclado.nextLine();
        }

        System.out.println("Digite o nome que deseja procurar: ");
        String nome = teclado.nextLine();

        for (int i = 0; i < fila.length; i++) {
            if(fila[i].equals(nome)) {
                System.out.println(i + 1);
                break;
            }
        }
    }
}
