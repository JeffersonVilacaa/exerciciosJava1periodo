package etapa3.C12;

import java.util.Arrays;
import java.util.Scanner;

public class C12EX09 {
    public static void main(String[] args) {
        int[] nums = new int[10];

        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < nums.length; i++) {
            System.out.print("Numero " + (i + 1) + ": ");
            nums[i] = sc.nextInt();
        }
        for (int i = 0; i < nums.length; i++) {
            if (Arrays.stream(nums).sum() % nums[i] == 0) {
                System.out.print(nums[i] + "|");
            }
        }
    }
}

