package etapa3.C12;

import java.util.Scanner;

public class C12EX25 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("Digite sua frase: ");
        String frase = teclado.nextLine();

        String[] palavras = frase.split(" ");

        for (int i = 0; i < palavras.length; i++) {
            System.out.println(palavras[i]);
        }
    }
}

