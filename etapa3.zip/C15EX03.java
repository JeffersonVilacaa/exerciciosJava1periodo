package etapa3.C15;

public class C15EX03 {
    public static void main(String[] args) {
        // Criando objetos da classe C15EX02 (ProdutoDuravel)
        C15EX02 produto1 = new C15EX02(1, "Mesa de Madeira", 299.90, 5, "Móveis", 12, "Madeira");
        C15EX02 produto2 = new C15EX02(2, "Cadeira de Plástico", 49.99, 10, "Móveis", 6, "Plástico");
        C15EX02 produto3 = new C15EX02(3, "Panela de Ferro Fundido", 159.99, 3, "Utensílios Domésticos", 24, "Ferro");

        // Imprimindo os detalhes dos produtos
        System.out.println("Detalhes dos Produtos Duráveis:");
        produto1.exibirDetalhesProdutoDuravel();
        System.out.println();
        produto2.exibirDetalhesProdutoDuravel();
        System.out.println();
        produto3.exibirDetalhesProdutoDuravel();
    }
}
