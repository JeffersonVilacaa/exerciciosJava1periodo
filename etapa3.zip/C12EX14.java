package etapa3.C12;

import java.util.Scanner;

public class C12EX14 {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] bilhete = new int[10];

        for (int i = 0; i < bilhete.length; i++) {
            System.out.println("Digite o numero dos bilhetes: ");
            bilhete[i] = teclado.nextInt();
        }

        System.out.println("Digite o numero do premiado: ");
        int premiado = teclado.nextInt();

        for (int i = 0; i < bilhete.length; i++) {
            if (bilhete[i] == premiado) {
                System.out.println("FOI PREMIADO!!");
                System.exit(0);
            }
        }
        System.out.println("Não foi dessa vez :C");
    }
}
